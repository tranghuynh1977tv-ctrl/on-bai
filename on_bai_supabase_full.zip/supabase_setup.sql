
-- ============================================================
-- ÔN BÀI - SUPABASE DATABASE SETUP
-- Chạy toàn bộ file này trong Supabase SQL Editor.
-- ============================================================

create extension if not exists "pgcrypto";

-- 1) Hồ sơ người dùng
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

-- Tự tạo profile khi có tài khoản Auth mới
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name','')
  )
  on conflict (id) do update
  set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- 2) Hàm kiểm tra admin
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- 3) Môn học
create table if not exists public.subjects (
  id text primary key,
  name text not null,
  icon text default '📚',
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

-- 4) Bài học
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  subject_id text not null references public.subjects(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

-- 5) Câu hỏi
create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  question text not null,
  option_a text not null,
  option_b text not null,
  option_c text not null,
  option_d text not null,
  correct_answer char(1) not null check (correct_answer in ('A','B','C','D')),
  explanation text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 6) Lịch sử làm bài
create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  correct_count integer not null default 0,
  total_count integer not null default 0,
  score numeric(5,2) not null default 0,
  answers jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_lessons_subject on public.lessons(subject_id);
create index if not exists idx_questions_lesson on public.questions(lesson_id);
create index if not exists idx_attempts_user on public.attempts(user_id);

-- 7) RLS
alter table public.profiles enable row level security;
alter table public.subjects enable row level security;
alter table public.lessons enable row level security;
alter table public.questions enable row level security;
alter table public.attempts enable row level security;

-- Profiles: user xem/sửa profile của mình; admin xem tất cả
drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin"
on public.profiles for select
to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
on public.profiles for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());

-- Nội dung học: ai cũng được đọc
drop policy if exists "subjects_read" on public.subjects;
create policy "subjects_read"
on public.subjects for select
to anon, authenticated
using (true);

drop policy if exists "lessons_read" on public.lessons;
create policy "lessons_read"
on public.lessons for select
to anon, authenticated
using (true);

drop policy if exists "questions_read" on public.questions;
create policy "questions_read"
on public.questions for select
to anon, authenticated
using (true);

-- Chỉ admin được thêm/sửa/xóa nội dung
drop policy if exists "subjects_admin_insert" on public.subjects;
create policy "subjects_admin_insert" on public.subjects for insert
to authenticated with check (public.is_admin());

drop policy if exists "subjects_admin_update" on public.subjects;
create policy "subjects_admin_update" on public.subjects for update
to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "subjects_admin_delete" on public.subjects;
create policy "subjects_admin_delete" on public.subjects for delete
to authenticated using (public.is_admin());

drop policy if exists "lessons_admin_insert" on public.lessons;
create policy "lessons_admin_insert" on public.lessons for insert
to authenticated with check (public.is_admin());

drop policy if exists "lessons_admin_update" on public.lessons;
create policy "lessons_admin_update" on public.lessons for update
to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "lessons_admin_delete" on public.lessons;
create policy "lessons_admin_delete" on public.lessons for delete
to authenticated using (public.is_admin());

drop policy if exists "questions_admin_insert" on public.questions;
create policy "questions_admin_insert" on public.questions for insert
to authenticated with check (public.is_admin());

drop policy if exists "questions_admin_update" on public.questions;
create policy "questions_admin_update" on public.questions for update
to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "questions_admin_delete" on public.questions;
create policy "questions_admin_delete" on public.questions for delete
to authenticated using (public.is_admin());

-- Lịch sử: user chỉ được tạo/xem lịch sử của chính mình
drop policy if exists "attempts_select_own" on public.attempts;
create policy "attempts_select_own"
on public.attempts for select
to authenticated
using (user_id = auth.uid() or public.is_admin());

drop policy if exists "attempts_insert_own" on public.attempts;
create policy "attempts_insert_own"
on public.attempts for insert
to authenticated
with check (user_id = auth.uid());

-- Quyền Data API tối thiểu
grant select on public.subjects, public.lessons, public.questions to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant insert, select on public.attempts to authenticated;
grant insert, update, delete on public.subjects, public.lessons, public.questions to authenticated;

-- 8) Dữ liệu mẫu
insert into public.subjects (id,name,icon,sort_order) values
('math','Toán','🧮',1),
('literature','Ngữ Văn','📕',2),
('english','Tiếng Anh','🔤',3),
('physics','Vật Lý','⚛️',4),
('chemistry','Hóa Học','⚗️',5),
('history','Lịch Sử','🏛️',6),
('geography','Địa Lý','🌍',7)
on conflict (id) do nothing;

insert into public.lessons (subject_id,name,sort_order)
select 'math','Mệnh đề - Tập hợp',1
where not exists (select 1 from public.lessons where subject_id='math' and name='Mệnh đề - Tập hợp');

insert into public.lessons (subject_id,name,sort_order)
select 'chemistry','Hóa học cơ bản',1
where not exists (select 1 from public.lessons where subject_id='chemistry' and name='Hóa học cơ bản');

insert into public.lessons (subject_id,name,sort_order)
select 'english','Ngữ pháp cơ bản',1
where not exists (select 1 from public.lessons where subject_id='english' and name='Ngữ pháp cơ bản');

-- Câu mẫu Toán
insert into public.questions
(lesson_id,question,option_a,option_b,option_c,option_d,correct_answer,explanation)
select l.id,
'Tập hợp các số tự nhiên nhỏ hơn 5 là:',
'{0, 1, 2, 3, 4}','{1, 2, 3, 4, 5}','{0, 1, 2, 3, 4, 5}','{1, 2, 3, 4}',
'A','Các số tự nhiên nhỏ hơn 5 là 0, 1, 2, 3, 4.'
from public.lessons l
where l.subject_id='math' and l.name='Mệnh đề - Tập hợp'
and not exists (select 1 from public.questions q where q.lesson_id=l.id);

-- Câu mẫu Hóa
insert into public.questions
(lesson_id,question,option_a,option_b,option_c,option_d,correct_answer,explanation)
select l.id,
'Công thức hóa học của nước là:',
'CO₂','H₂O','O₂','NaCl',
'B','Một phân tử nước gồm hai nguyên tử H và một nguyên tử O.'
from public.lessons l
where l.subject_id='chemistry' and l.name='Hóa học cơ bản'
and not exists (select 1 from public.questions q where q.lesson_id=l.id);

-- Câu mẫu Anh
insert into public.questions
(lesson_id,question,option_a,option_b,option_c,option_d,correct_answer,explanation)
select l.id,
'Choose the correct sentence:',
'She go to school.','She goes to school.','She going school.','She gone school.',
'B','Với chủ ngữ ngôi thứ ba số ít ở thì hiện tại đơn, động từ thường thêm -s/-es.'
from public.lessons l
where l.subject_id='english' and l.name='Ngữ pháp cơ bản'
and not exists (select 1 from public.questions q where q.lesson_id=l.id);

-- Sau khi đăng ký tài khoản bằng email của bro, chạy:
-- update public.profiles set role='admin' where email='EMAIL_CUA_BRO';
