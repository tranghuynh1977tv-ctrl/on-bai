// ĐIỀN 2 GIÁ TRỊ LẤY TỪ SUPABASE PROJECT SETTINGS
// Không dùng service_role key ở đây.
// Chỉ dùng Publishable key/anon key cho trình duyệt.

window.SUPABASE_CONFIG = {
  url: "https://YOUR-PROJECT.supabase.co",
  key: "YOUR-PUBLISHABLE-KEY"
};
