ÔN BÀI - BẢN SUPABASE

MỤC TIÊU
- Đăng ký / đăng nhập bằng email + mật khẩu.
- Câu hỏi lưu trong PostgreSQL online của Supabase.
- Lịch sử điểm lưu theo từng tài khoản.
- Admin có thể thêm/xóa câu hỏi bằng điện thoại.
- RLS bảo vệ database: chỉ admin được sửa nội dung; học sinh chỉ đọc câu hỏi và ghi lịch sử của mình.

CÀI ĐẶT TRÊN ĐIỆN THOẠI
1. Tạo project trên Supabase.
2. Mở SQL Editor và chạy toàn bộ file supabase_setup.sql.
3. Vào Project Settings / API và lấy Project URL + Publishable key (hoặc anon key nếu dashboard của bạn hiển thị tên cũ).
4. Mở config.js và thay:
   YOUR-PROJECT
   YOUR-PUBLISHABLE-KEY
5. Đưa index.html + config.js lên một hosting tĩnh có HTTPS.
6. Mở web, đăng ký tài khoản.
7. Trong Supabase SQL Editor chạy:
   update public.profiles
   set role='admin'
   where email='EMAIL_CUA_BRO';
8. Đăng nhập lại. Nút tài khoản sẽ cho mở trang quản trị.

LƯU Ý BẢO MẬT
- Tuyệt đối KHÔNG dán service_role key vào config.js hoặc mã chạy trên trình duyệt.
- Chỉ dùng Publishable/anon key ở frontend; RLS là lớp bảo vệ quyền dữ liệu.
- Khi triển khai thật nên bật xác nhận email và đặt URL redirect của Auth đúng với domain web.

CẤU TRÚC
index.html              -> giao diện + chức năng
config.js               -> URL/key của Supabase
supabase_setup.sql      -> bảng, trigger, RLS, dữ liệu mẫu
